from ReadBook import *
import mysql.connector as mysql
from tkinter import *
from PIL import ImageTk,Image #PIL -> Pillow
import pymysql
from tkinter import messagebox
#from Login import *
from AddBook import *
from DeleteBook import *
from ReturnBook import returnBook
from ViewBooks import *
from IssueBook import *
#GUI

def adminlog():
    global username, password
    root = Tk()
    root.title("Library")
    root.minsize(width=400, height=400)
    root.geometry("600x500")
    Canvas1 = Canvas(root)
    Canvas1.config(bg="#D6ED17")
    Canvas1.pack(expand=True, fill=BOTH)
    headingframe = Frame(root, bd=5)
    headingframe.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)
    headinglabel = Label(headingframe, text="Login", font=("Courier", 15))
    headinglabel.place(relx=0, rely=0, relheight=1, relwidth=1)
    labelframe = Frame(root, bg="black")
    labelframe.place(relx=0.1, rely=0.4, relwidth=0.8, relheight=0.4)

    lb1 = Label(labelframe, text="Name: ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.2, relheight=0.08)

    username = Entry(labelframe)
    username.place(relx=0.3, rely=0.2, relheight=0.08, relwidth=0.4)

    lb2 = Label(labelframe, text="Password: ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.35, relheight=0.08)

    password = Entry(labelframe)
    password.place(relx=0.3, rely=0.35, relheight=0.08, relwidth=0.4)

    SubmitBtn = Button(root, text="SUBMIT", bg='#d1ccc0', fg='black', command=runadmin)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)
    root.mainloop()


def userlog():
    global password, username
    root = Tk()
    root.title("Library")
    root.minsize(width=400, height=400)
    root.geometry("600x500")
    Canvas1 = Canvas(root)
    Canvas1.config(bg="#D6ED17")
    Canvas1.pack(expand=True, fill=BOTH)
    headingframe = Frame(root, bd=5)
    headingframe.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)
    headinglabel = Label(headingframe, text="Login", font=("Courier", 15))
    headinglabel.place(relx=0, rely=0, relheight=1, relwidth=1)
    labelframe = Frame(root, bg="black")
    labelframe.place(relx=0.1, rely=0.4, relwidth=0.8, relheight=0.4)

    lb1 = Label(labelframe, text="Name: ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.2, relheight=0.08)

    username = Entry(labelframe)
    username.place(relx=0.3, rely=0.2, relheight=0.08, relwidth=0.4)

    lb2 = Label(labelframe, text="Password: ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.35, relheight=0.08)

    password = Entry(labelframe)
    password.place(relx=0.3, rely=0.35, relheight=0.08, relwidth=0.4)

    SubmitBtn = Button(root, text="SUBMIT", bg='#d1ccc0', fg='black', command=runuse)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)
    root.mainloop()



def mainAdmin():
    root = Tk()
    root.title("Library")
    root.minsize(width=400,height=400)
    root.geometry("600x500")

    same=True
    n=3.9
    background_image=Image.open("library.jpg")
    [imageSizeWidth, imageSizeHeight] = background_image.size

    newImageSizeWidth = int(imageSizeWidth*n)
    if same:
        newImageSizeHeight = int(imageSizeHeight*n)
    else:
        newImageSizeHeight = int(imageSizeHeight/n)
    background_image = background_image.resize((newImageSizeWidth,newImageSizeHeight),Image.ANTIALIAS)
    img = ImageTk.PhotoImage(background_image,master=root)


    Canvas1 = Canvas(root)
    Canvas1.create_image(300,340,image = img)
    Canvas1.config(bg="white",width = newImageSizeWidth, height = newImageSizeHeight)
    Canvas1.pack(expand=True,fill=BOTH)

    headingFrame1 = Frame(root,bg="#FFBB00",bd=5)
    headingFrame1.place(relx=0.2,rely=0.1,relwidth=0.6,relheight=0.16)
    headingLabel = Label(headingFrame1, text="Welcome to\n BRS Library", bg='black', fg='white', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)

    btn1 = Button(root, text="Add Book Details", bg='black', fg='white', command=addBook)
    btn1.place(relx=0.28, rely=0.4, relwidth=0.45, relheight=0.1)

    btn2 = Button(root, text="Delete Book", bg='black', fg='white', command=delete)
    btn2.place(relx=0.28, rely=0.5, relwidth=0.45, relheight=0.1)

    btn3 = Button(root, text="View Book List", bg='black', fg='white', command=View)
    btn3.place(relx=0.28, rely=0.6, relwidth=0.45, relheight=0.1)

    btn6= Button(root, text="Read Book", bg='black', fg='white',command=getID)
    btn6.place(relx=0.28,rely=0.7,relwidth=0.45,relheight=0.1)
    root.mainloop()


def mainUser():
    root = Tk()
    root.title("Library")
    root.minsize(width=400, height=400)
    root.geometry("600x500")

    same = True
    n = 3.9
    background_image = Image.open("library.jpg")
    [imageSizeWidth, imageSizeHeight] = background_image.size

    newImageSizeWidth = int(imageSizeWidth * n)
    if same:
        newImageSizeHeight = int(imageSizeHeight * n)
    else:
        newImageSizeHeight = int(imageSizeHeight / n)
    background_image = background_image.resize((newImageSizeWidth, newImageSizeHeight), Image.ANTIALIAS)
    img = ImageTk.PhotoImage(background_image,master=root)

    Canvas1 = Canvas(root)
    Canvas1.create_image(300, 340, image=img)
    Canvas1.config(bg="white", width=newImageSizeWidth, height=newImageSizeHeight)
    Canvas1.pack(expand=True, fill=BOTH)

    headingFrame1 = Frame(root, bg="#FFBB00", bd=5)
    headingFrame1.place(relx=0.2, rely=0.1, relwidth=0.6, relheight=0.16)
    headingLabel = Label(headingFrame1, text="Welcome to\n BRS Library", bg='black', fg='white', font=('Courier', 15))
    headingLabel.place(relx=0, rely=0, relwidth=1, relheight=1)

    btn3 = Button(root, text="View Book List", bg='black', fg='white', command=View)
    btn3.place(relx=0.28, rely=0.6, relwidth=0.45, relheight=0.1)

    btn6 = Button(root, text="Read Book", bg='black', fg='white', command=getID)
    btn6.place(relx=0.28, rely=0.7, relwidth=0.45, relheight=0.1)
    root.mainloop()


def runadmin():
    n = username.get()
    pas = password.get()
    cur.execute("Select * from adminlogin")
    tup = cur.fetchall()
    for i in tup:
        print(i[0])
        if i[0] == n and i[1] == pas:
            messagebox.showinfo('Success')
            mainAdmin()

    else:
        messagebox.showinfo('error', 'user not found!')


def runuse():
    n = username.get()
    pas = password.get()
    cur.execute("Select * from userlogin")

    tup = cur.fetchall()
    for i in tup:
        print(i[0])
        if i[0] == n and i[1] == pas:
            messagebox.showinfo('Success')
            mainUser()

        else:
            messagebox.showinfo('error', 'user not found!')


# connecting to mysql server
def start():
    root = Tk()
    root.title("Library")
    root.minsize(width=400,height=400)
    root.geometry("600x500")


    headingframe1=Frame(root,bg='#FFBB00',bd=5)
    headingframe1.place(relx=0.2,rely=0.1,relwidth=0.6,relheight=0.16)
    headinglabel=Label(headingframe1,text="BRS LIBRARY\nLogin")
    headinglabel.place(relx=0,rely=0,relwidth=1,relheight=1)
    btn3 = Button(root, text="Admin", bg='black', fg='white', command=adminlog)
    btn3.place(relx=0.28, rely=0.6, relwidth=0.45, relheight=0.1)

    btn6 = Button(root, text="User", bg='black', fg='white', command=userlog)
    btn6.place(relx=0.28, rely=0.7, relwidth=0.45, relheight=0.1)
    root.mainloop()

start()


def adminlog():
    global username, password
    root = Tk()
    root.title("Library")
    root.minsize(width=400, height=400)
    root.geometry("600x500")
    Canvas1 = Canvas(root)
    Canvas1.config(bg="#D6ED17")
    Canvas1.pack(expand=True, fill=BOTH)
    headingframe = Frame(root, bd=5)
    headingframe.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)
    headinglabel = Label(headingframe, text="Login", font=("Courier", 15))
    headinglabel.place(relx=0, rely=0, relheight=1, relwidth=1)
    labelframe = Frame(root, bg="black")
    labelframe.place(relx=0.1, rely=0.4, relwidth=0.8, relheight=0.4)

    lb1 = Label(labelframe, text="Name: ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.2, relheight=0.08)

    username = Entry(labelframe)
    username.place(relx=0.3, rely=0.2, relheight=0.08, relwidth=0.4)

    lb2 = Label(labelframe, text="Password: ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.35, relheight=0.08)

    password = Entry(labelframe)
    password.place(relx=0.3, rely=0.35, relheight=0.08, relwidth=0.4)

    SubmitBtn = Button(root, text="SUBMIT", bg='#d1ccc0', fg='black', command=runadmin)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)
    root.mainloop()


def userlog():
    global password, username
    root = Tk()
    root.title("Library")
    root.minsize(width=400, height=400)
    root.geometry("600x500")
    Canvas1 = Canvas(root)
    Canvas1.config(bg="#D6ED17")
    Canvas1.pack(expand=True, fill=BOTH)
    headingframe = Frame(root, bd=5)
    headingframe.place(relx=0.25, rely=0.1, relwidth=0.5, relheight=0.13)
    headinglabel = Label(headingframe, text="Login", font=("Courier", 15))
    headinglabel.place(relx=0, rely=0, relheight=1, relwidth=1)
    labelframe = Frame(root, bg="black")
    labelframe.place(relx=0.1, rely=0.4, relwidth=0.8, relheight=0.4)

    lb1 = Label(labelframe, text="Name: ", bg='black', fg='white')
    lb1.place(relx=0.05, rely=0.2, relheight=0.08)

    username = Entry(labelframe)
    username.place(relx=0.3, rely=0.2, relheight=0.08, relwidth=0.4)

    lb2 = Label(labelframe, text="Password: ", bg='black', fg='white')
    lb2.place(relx=0.05, rely=0.35, relheight=0.08)

    password = Entry(labelframe)
    password.place(relx=0.3, rely=0.35, relheight=0.08, relwidth=0.4)

    SubmitBtn = Button(root, text="SUBMIT", bg='#d1ccc0', fg='black', command=runuse)
    SubmitBtn.place(relx=0.28, rely=0.9, relwidth=0.18, relheight=0.08)
    root.mainloop()


def runadmin():
    n = username.get()
    pas = password.get()
    cur.execute("Select * from adminlogin")
    tup = cur.fetchall()
    for i in tup:
        print(i[0])
        if i[0] == n and i[1] == pas:
            messagebox.showinfo('Success')
        else:
            messagebox.showinfo('error', 'user not found!')


mypass = "aniachin2011#"
mydatabase = "db"
data = pymysql.connect(host="localhost",user='root',password=mypass,database=mydatabase)
cur = data.cursor

